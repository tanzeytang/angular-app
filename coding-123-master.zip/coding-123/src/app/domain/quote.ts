export interface Quote {
  cn: string;
  en: string;
  pic: string;
}
